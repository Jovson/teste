
public class Ingresso {
	private int valor;

	public void imprimirValorIngresso() {

	}

	public int getValor() {
		return valor;
	}

	public void setValor(int valor) {
		this.valor = valor;
	}

	@Override
	public String toString() {
		return "Ingresso [valor=" + valor + "]";
	}

}
