public class IngressoVIP extends Ingresso {

	private int ValorAdicional;

	public void imprimirValorVIP() {

	}

	public int getValorAdicional() {
		return ValorAdicional;
	}

	public void setValorAdicional(int valorAdicional) {
		ValorAdicional = valorAdicional;
	}

}
